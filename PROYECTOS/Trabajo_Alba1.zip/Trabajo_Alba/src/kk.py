import os
print("\n"*5)
print("hola")
fichero="C:\\Program Files (x86)\\Adobe\\Acrobat Reader DC\\ReadMe.htm"
__name__="__main__"
print(fichero)
print(os.path.dirname(fichero))
print("adios")